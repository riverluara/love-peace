*Use this directory to manage overall project documentation (presentations, art, research/references, user manuals, test plans & results, etc.) Update this README as needed to describe how doc/ is organized.*




## [Design Documentation](DesignDoc.md)

Click above for details of the PROJECT design documentation.


## [Setup Guide](SetupGuide.md)

Click above for details about how to setup your development environment to work on this project.
